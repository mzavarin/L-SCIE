
R1
in this update, we corrected the Kd standard deviation calculation so that a minimum value is based on the sorbate uncertainty which is hard wired at 5%

R2
Here, we continue the cleanup of jaea by deleting rows that do not have the required sorbate concentration, Kd, and solid/liquid ration information that is essential for making any downstream calculations
  
The total decreases from a starting point of 39451 data to 35157 after filtering out missing data.

the JAEA database originally contained 69788 total data which includes rocks, engineered materials, and minerals.

4/30/25

last step is setting tot, aq, and s values that are below the sd to the sd.
actually, we discontinued this approach. instead, only values less that 0 are set to the SD

R3
3/23/26
updated the workflow to capture nearly all the JAEA data, including rocks and engineered materials.