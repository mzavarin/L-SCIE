calculating the error in the Kd value.
we assume that a logKd error of 0.2 is valid.  in that case,
the Kd error should be 0.58*Kd

-5
0.2
5.84893E-06
0.00001
0.584893192
